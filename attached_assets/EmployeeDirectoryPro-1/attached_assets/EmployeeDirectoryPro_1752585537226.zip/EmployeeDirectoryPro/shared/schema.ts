import { pgTable, text, timestamp, boolean, integer, uuid, json, serial, varchar } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';
import { relations } from 'drizzle-orm';

// Users table - for authentication
export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  employee_id: text('employee_id').notNull().unique(),
  phone_number: text('phone_number').notNull(),
  is_verified: boolean('is_verified').default(false),
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow()
});

export const usersRelations = relations(users, ({ many, one }) => ({
  sessions: many(sessions),
  employee: one(employees, {
    fields: [users.employee_id],
    references: [employees.employee_id]
  }),
  sentMessages: many(notificationMessages, {
    relationName: 'sender'
  }),
  groupMemberships: many(notificationGroupMembers)
}));

// Sessions table
export const sessions = pgTable('sessions', {
  id: uuid('id').defaultRandom().primaryKey(),
  user_id: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expires_at: timestamp('expires_at').notNull(),
  created_at: timestamp('created_at').defaultNow()
});

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.user_id],
    references: [users.id]
  })
}));

// OTP codes table
export const otpCodes = pgTable('otp_codes', {
  id: uuid('id').defaultRandom().primaryKey(),
  employee_id: text('employee_id').notNull(),
  otp_code: text('otp_code').notNull(),
  expires_at: timestamp('expires_at').notNull(),
  is_used: boolean('is_used').default(false),
  created_at: timestamp('created_at').defaultNow()
});

// Employees table - comprehensive employee data
export const employees = pgTable('employees', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  employee_id: text('employee_id').notNull().unique(),
  designation: text('designation'),
  department: text('department'),
  email: text('email'),
  location: text('location'),
  created_at: timestamp('created_at').defaultNow(),
  
  // Personal Information
  area_name: text('area_name'),
  unit_name: text('unit_name'),
  dob: text('dob'),
  father_name: text('father_name'),
  category: text('category'),
  grade: text('grade'),
  discipline: text('discipline'),
  
  // Financial Information
  bank_acc_no: text('bank_acc_no'),
  bank: text('bank'),
  cmpf: text('cmpf'),
  
  // Department Information
  dept_code: text('dept_code'),
  sub_dept: text('sub_dept'),
  
  // Dates
  dt_appt: text('dt_appt'),
  area_joining_date: text('area_joining_date'),
  grade_joining_date: text('grade_joining_date'),
  incr_date: text('incr_date'),
  expected_exit_date: text('expected_exit_date'),
  
  // Other Details
  pay_flag: text('pay_flag'),
  aadhaar: text('aadhaar'),
  pan_no: text('pan_no'),
  email_id: text('email_id'),
  phno_1: text('phno_1'),
  phno_2: text('phno_2'),
  gender: text('gender'),
  
  // Address
  present_address: text('present_address'),
  permanent_address: text('permanent_address'),
  
  // Family Information
  spouse_name: text('spouse_name'),
  spouse_emp_code: text('spouse_emp_code'),
  
  // Other Information
  caste_code: text('caste_code'),
  religion_code: text('religion_code'),
  ex_emp_relation: text('ex_emp_relation'),
  marital_status: text('marital_status'),
  staff_type: text('staff_type'),
  sal_mode: text('sal_mode'),
  basic_pay: text('basic_pay'),
  house_rent: text('house_rent'),
  incr_month: text('incr_month'),
  next_incr_amt: text('next_incr_amt'),
  passport_no: text('passport_no'),
  ret_date: text('ret_date'),
  blood_group: text('blood_group'),
  
  // Profile Image
  profile_image: text('profile_image')
});

export const employeesRelations = relations(employees, ({ one }) => ({
  user: one(users, {
    fields: [employees.employee_id],
    references: [users.employee_id]
  })
}));

// Notification Groups
export const notificationGroups = pgTable('notification_groups', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  employee_ids: text('employee_ids').array().notNull(),
  created_by: uuid('created_by').notNull().references(() => users.id),
  created_at: timestamp('created_at').defaultNow()
});

export const notificationGroupsRelations = relations(notificationGroups, ({ many, one }) => ({
  members: many(notificationGroupMembers),
  messages: many(notificationMessages),
  creator: one(users, {
    fields: [notificationGroups.created_by],
    references: [users.id]
  })
}));

// Notification Group Members
export const notificationGroupMembers = pgTable('notification_group_members', {
  id: uuid('id').defaultRandom().primaryKey(),
  group_id: uuid('group_id').notNull().references(() => notificationGroups.id, { onDelete: 'cascade' }),
  user_id: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  employee_id: text('employee_id').notNull(),
  created_at: timestamp('created_at').defaultNow()
});

export const notificationGroupMembersRelations = relations(notificationGroupMembers, ({ one }) => ({
  group: one(notificationGroups, {
    fields: [notificationGroupMembers.group_id],
    references: [notificationGroups.id]
  }),
  user: one(users, {
    fields: [notificationGroupMembers.user_id],
    references: [users.id]
  })
}));

// Notification Messages
export const notificationMessages = pgTable('notification_messages', {
  id: uuid('id').defaultRandom().primaryKey(),
  group_id: uuid('group_id').notNull().references(() => notificationGroups.id, { onDelete: 'cascade' }),
  sender_id: uuid('sender_id').notNull().references(() => users.id),
  sender_name: text('sender_name').notNull(),
  content: text('content').notNull(),
  created_at: timestamp('created_at').defaultNow()
});

export const notificationMessagesRelations = relations(notificationMessages, ({ one }) => ({
  group: one(notificationGroups, {
    fields: [notificationMessages.group_id],
    references: [notificationGroups.id]
  }),
  sender: one(users, {
    fields: [notificationMessages.sender_id],
    references: [users.id],
    relationName: 'sender'
  })
}));

// Insert Schemas and Types
export const insertUserSchema = createInsertSchema(users).omit({ id: true, created_at: true, updated_at: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, created_at: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export const insertOtpCodeSchema = createInsertSchema(otpCodes).omit({ id: true, created_at: true });
export type InsertOtpCode = z.infer<typeof insertOtpCodeSchema>;
export type OtpCode = typeof otpCodes.$inferSelect;

export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true, created_at: true });
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

export const insertNotificationGroupSchema = createInsertSchema(notificationGroups).omit({ id: true, created_at: true });
export type InsertNotificationGroup = z.infer<typeof insertNotificationGroupSchema>;
export type NotificationGroup = typeof notificationGroups.$inferSelect;

export const insertNotificationGroupMemberSchema = createInsertSchema(notificationGroupMembers).omit({ id: true, created_at: true });
export type InsertNotificationGroupMember = z.infer<typeof insertNotificationGroupMemberSchema>;
export type NotificationGroupMember = typeof notificationGroupMembers.$inferSelect;

export const insertNotificationMessageSchema = createInsertSchema(notificationMessages).omit({ id: true, created_at: true });
export type InsertNotificationMessage = z.infer<typeof insertNotificationMessageSchema>;
export type NotificationMessage = typeof notificationMessages.$inferSelect;