import { readFileSync } from 'fs';
import { join } from 'path';
import { db } from '../server/db.js';
import { employees, users, sessions, otpCodes, notificationGroups, notificationGroupMembers, notificationMessages } from '../shared/schema.js';
import { parse } from 'csv-parse/sync';

async function importData() {
  console.log('Starting data import...');

  try {
    // Import employees from CSV
    console.log('Importing employees...');
    const employeesCsv = readFileSync(join(process.cwd(), 'attached_assets/employees_1752582130209.csv'), 'utf-8');
    const employeesData = parse(employeesCsv, {
      columns: true,
      skip_empty_lines: true,
    });

    for (const employee of employeesData) {
      await db.insert(employees).values({
        name: employee.name || '',
        employee_id: employee.employee_id || '',
        designation: employee.designation || null,
        department: employee.department || null,
        discipline: employee.discipline || null,
        grade: employee.grade || null,
        category: employee.category || null,
        cadre: employee.cadre || null,
        unit_name: employee.unit_name || null,
        area_name: employee.area_name || null,
        location: employee.location || null,
        dob: employee.dob || null,
        gender: employee.gender || null,
        father_name: employee.father_name || null,
        present_address: employee.present_address || null,
        permanent_address: employee.permanent_address || null,
        marital_status: employee.marital_status || null,
        spouse_name: employee.spouse_name || null,
        phno_1: employee.phno_1 || null,
        phno_2: employee.phno_2 || null,
        email: employee.email || null,
        email_id: employee.email_id || null,
        religion_code: employee.religion_code || null,
        blood_group: employee.blood_group || null,
        aadhaar: employee.aadhaar || null,
        pan_no: employee.pan_no || null,
        bank: employee.bank || null,
        bank_acc_no: employee.bank_acc_no || null,
        cmpf: employee.cmpf || null,
        basic_pay: employee.basic_pay || null,
        dt_appt: employee.dt_appt || null,
        dt_join: employee.dt_join || null,
        area_joining_date: employee.area_joining_date || null,
        expected_exit_date: employee.expected_exit_date || null,
        profile_image: null,
      }).onConflictDoNothing();
    }
    console.log(`Imported ${employeesData.length} employees`);

    // Import users
    console.log('Importing users...');
    const usersJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/users_1752582130208.json'), 'utf-8'));
    
    for (const user of usersJson) {
      await db.insert(users).values({
        employee_id: user.employee_id,
        phone_number: user.phone_number || null,
        is_verified: user.is_verified || false,
        is_admin: user.is_admin || false,
        created_at: user.created_at ? new Date(user.created_at) : new Date(),
        updated_at: user.updated_at ? new Date(user.updated_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${usersJson.length} users`);

    // Import sessions
    console.log('Importing sessions...');
    const sessionsJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/sessions_1752582130208.json'), 'utf-8'));
    
    for (const session of sessionsJson) {
      await db.insert(sessions).values({
        user_id: session.user_id,
        expires_at: new Date(session.expires_at),
        created_at: session.created_at ? new Date(session.created_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${sessionsJson.length} sessions`);

    // Import OTP codes
    console.log('Importing OTP codes...');
    const otpCodesJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/otp_codes_1752582130208.json'), 'utf-8'));
    
    for (const otp of otpCodesJson) {
      await db.insert(otpCodes).values({
        employee_id: otp.employee_id,
        otp_code: otp.otp_code,
        expires_at: new Date(otp.expires_at),
        is_used: otp.is_used || false,
        created_at: otp.created_at ? new Date(otp.created_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${otpCodesJson.length} OTP codes`);

    // Import notification groups
    console.log('Importing notification groups...');
    const groupsJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/notification_groups_1752582130208.json'), 'utf-8'));
    
    for (const group of groupsJson) {
      await db.insert(notificationGroups).values({
        name: group.name,
        created_by: group.created_by,
        created_at: group.created_at ? new Date(group.created_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${groupsJson.length} notification groups`);

    // Import notification group members
    console.log('Importing notification group members...');
    const membersJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/notification_group_members_1752582130208.json'), 'utf-8'));
    
    for (const member of membersJson) {
      await db.insert(notificationGroupMembers).values({
        group_id: member.group_id,
        user_id: member.user_id,
        created_at: member.created_at ? new Date(member.created_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${membersJson.length} notification group members`);

    // Import notification messages
    console.log('Importing notification messages...');
    const messagesJson = JSON.parse(readFileSync(join(process.cwd(), 'attached_assets/notification_messages_1752582130208.json'), 'utf-8'));
    
    for (const message of messagesJson) {
      await db.insert(notificationMessages).values({
        group_id: message.group_id,
        sender_id: message.sender_id,
        sender_name: message.sender_name,
        content: message.content,
        created_at: message.created_at ? new Date(message.created_at) : new Date(),
      }).onConflictDoNothing();
    }
    console.log(`Imported ${messagesJson.length} notification messages`);

    console.log('Data import completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error importing data:', error);
    process.exit(1);
  }
}

importData();