// Employee Directory PWA Main Entry Point
console.log('🚀 Employee Directory PWA - Starting...');
console.log('📊 Database:', process.env.DATABASE_URL ? 'Connected' : 'Not configured');
console.log('🔑 SMS:', process.env.FAST2SMS_API_KEY ? 'Configured' : 'Not configured');
console.log('');

// Import and start the server
require('./start.js');