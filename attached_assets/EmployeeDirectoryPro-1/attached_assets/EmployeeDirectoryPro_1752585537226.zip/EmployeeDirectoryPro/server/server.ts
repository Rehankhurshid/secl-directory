import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import routes, { setupWebSocket } from './routes';
import { setupVite } from './vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Basic middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Static files for uploads
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// API routes
app.use('/api', routes);

// Create HTTP server
const httpServer = createServer(app);

// Setup WebSocket
setupWebSocket(httpServer, app);

// Setup Vite in development
if (process.env.NODE_ENV !== 'production') {
  await setupVite(app);
} else {
  // Serve production build
  app.use(express.static(path.join(__dirname, '../dist/client')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/client/index.html'));
  });
}

// Start server
httpServer.listen(port, () => {
  console.log(`Server running on port ${port}`);
});