import { Router } from 'express';
import { storage } from './storage.js';
import { WebSocketServer, WebSocket } from 'ws';
import http from 'http';

const router = Router();

// File upload will be handled later

// Middleware to check authentication
const requireAuth = async (req: any, res: any, next: any) => {
  const sessionId = req.session?.sessionId;
  if (!sessionId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const session = await storage.getSession(sessionId);
  if (!session || session.expires_at < new Date()) {
    return res.status(401).json({ error: 'Session expired' });
  }
  
  const user = await storage.getUser(session.user_id);
  if (!user) {
    return res.status(401).json({ error: 'User not found' });
  }
  
  req.user = user;
  next();
};

// Admin middleware
const requireAdmin = async (req: any, res: any, next: any) => {
  await requireAuth(req, res, async () => {
    if (req.user.employee_id !== 'ADMIN001') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    next();
  });
};

// Simple validation helper
const validateFields = (fields: string[]) => (req: any, res: any, next: any) => {
  for (const field of fields) {
    if (!req.body[field]) {
      return res.status(400).json({ error: `Missing required field: ${field}` });
    }
  }
  next();
};

// Generate 6-digit OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send SMS using Fast2SMS
const sendSMS = async (phoneNumber: string, otp: string) => {
  try {
    if (!process.env.FAST2SMS_API_KEY) {
      console.error('FAST2SMS_API_KEY not configured');
      return { success: false, error: 'SMS service not configured' };
    }
    
    const response = await fetch('https://www.fast2sms.com/dev/bulkV2', {
      method: 'POST',
      headers: {
        'authorization': process.env.FAST2SMS_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        variables_values: otp,
        route: 'otp',
        numbers: phoneNumber
      })
    });
    
    const data = await response.json();
    return { success: response.ok, data };
  } catch (error) {
    console.error('SMS sending failed:', error);
    return { success: false, error: 'Failed to send SMS' };
  }
};

// Auth Routes
router.post('/auth/generate-otp', validateFields(['employee_id']), async (req, res) => {
  try {
    const { employee_id } = req.body;
    
    // Check if employee exists
    const employee = await storage.getEmployeeByEmployeeId(employee_id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    // Get or create user
    let user = await storage.getUserByEmployeeId(employee_id);
    if (!user) {
      // Check if employee has phone number
      if (!employee.phno_1) {
        return res.status(400).json({ error: 'No phone number registered for this employee' });
      }
      
      user = await storage.createUser({
        employee_id,
        phone_number: employee.phno_1,
        is_verified: false
      });
    }
    
    // Generate OTP
    const otp = generateOTP();
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 5); // 5 minutes expiry
    
    await storage.createOtpCode({
      employee_id,
      otp_code: otp,
      expires_at: expiresAt,
      is_used: false
    });
    
    // Send SMS
    const smsResult = await sendSMS(user.phone_number, otp);
    
    // In development, also return OTP for testing
    const isDev = process.env.NODE_ENV === 'development';
    
    res.json({ 
      success: true, 
      message: 'OTP sent successfully',
      phone_number: user.phone_number.slice(0, -4) + '****',
      ...(isDev && { otp }) // Only include OTP in development
    });
  } catch (error) {
    console.error('Generate OTP error:', error);
    res.status(500).json({ error: 'Failed to generate OTP' });
  }
});

router.post('/auth/verify-otp', validateFields(['employee_id', 'otp_code']), async (req, res) => {
  try {
    const { employee_id, otp_code } = req.body;
    
    // Verify OTP
    const otpRecord = await storage.getValidOtpCode(employee_id, otp_code);
    if (!otpRecord) {
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }
    
    // Mark OTP as used
    await storage.markOtpAsUsed(otpRecord.id);
    
    // Get user and employee
    const user = await storage.getUserByEmployeeId(employee_id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update user as verified
    await storage.updateUser(user.id, { is_verified: true });
    
    // Create session
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days
    
    const session = await storage.createSession({
      user_id: user.id,
      expires_at: expiresAt
    });
    
    // Set session cookie
    res.cookie('sessionId', session.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });
    
    // Get employee data
    const employee = await storage.getEmployeeByEmployeeId(employee_id);
    
    res.json({
      success: true,
      user: {
        id: user.id,
        employee_id: user.employee_id,
        is_admin: user.employee_id === 'ADMIN001'
      },
      employee
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ error: 'Failed to verify OTP' });
  }
});

router.get('/auth/me', requireAuth, async (req: any, res) => {
  try {
    const employee = await storage.getEmployeeByEmployeeId(req.user.employee_id);
    
    res.json({
      user: {
        id: req.user.id,
        employee_id: req.user.employee_id,
        is_admin: req.user.employee_id === 'ADMIN001'
      },
      employee
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ error: 'Failed to get user data' });
  }
});

router.post('/auth/logout', requireAuth, async (req: any, res) => {
  try {
    if (req.session.sessionId) {
      await storage.deleteSession(req.session.sessionId);
    }
    res.clearCookie('sessionId');
    res.json({ success: true });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Failed to logout' });
  }
});

// Employee Routes
router.get('/employees', requireAuth, async (req: any, res) => {
  try {
    const options = {
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 20,
      search: req.query.search,
      department: req.query.department,
      designation: req.query.designation,
      location: req.query.location,
      category: req.query.category,
      grade: req.query.grade,
      gender: req.query.gender,
      blood_group: req.query.blood_group,
      sortBy: req.query.sortBy || 'name',
      sortOrder: req.query.sortOrder || 'asc'
    };
    
    const result = await storage.getEmployees(options);
    
    res.json({
      employees: result.employees,
      pagination: {
        page: options.page,
        limit: options.limit,
        total: result.total,
        totalPages: Math.ceil(result.total / options.limit)
      }
    });
  } catch (error) {
    console.error('Get employees error:', error);
    res.status(500).json({ error: 'Failed to get employees' });
  }
});

router.get('/employees/filter-options', requireAuth, async (req, res) => {
  try {
    const options = await storage.getFilterOptions();
    res.json(options);
  } catch (error) {
    console.error('Get filter options error:', error);
    res.status(500).json({ error: 'Failed to get filter options' });
  }
});

router.get('/employees/:id', requireAuth, async (req, res) => {
  try {
    const employee = await storage.getEmployee(req.params.id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json(employee);
  } catch (error) {
    console.error('Get employee error:', error);
    res.status(500).json({ error: 'Failed to get employee' });
  }
});

router.post('/employees', requireAdmin, async (req, res) => {
  try {
    const employee = await storage.createEmployee(req.body);
    res.status(201).json(employee);
  } catch (error) {
    console.error('Create employee error:', error);
    res.status(500).json({ error: 'Failed to create employee' });
  }
});

router.put('/employees/:id', requireAdmin, async (req, res) => {
  try {
    const employee = await storage.updateEmployee(req.params.id, req.body);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json(employee);
  } catch (error) {
    console.error('Update employee error:', error);
    res.status(500).json({ error: 'Failed to update employee' });
  }
});

router.delete('/employees/:id', requireAdmin, async (req, res) => {
  try {
    await storage.deleteEmployee(req.params.id);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete employee error:', error);
    res.status(500).json({ error: 'Failed to delete employee' });
  }
});

router.post('/employees/:id/profile-image', requireAuth, async (req: any, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image uploaded' });
    }
    
    const employee = await storage.updateEmployee(req.params.id, {
      profile_image: `/uploads/${req.file.filename}`
    });
    
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    
    res.json({ 
      success: true,
      profile_image: employee.profile_image
    });
  } catch (error) {
    console.error('Upload profile image error:', error);
    res.status(500).json({ error: 'Failed to upload image' });
  }
});

// Notification Routes
router.get('/notification/groups', requireAuth, async (req: any, res) => {
  try {
    const groups = await storage.getNotificationGroups(req.user.id);
    res.json(groups);
  } catch (error) {
    console.error('Get notification groups error:', error);
    res.status(500).json({ error: 'Failed to get notification groups' });
  }
});

router.post('/notification/groups', requireAuth, validateFields(['name', 'employee_ids']), async (req: any, res) => {
  try {
    const { name, employee_ids } = req.body;
    
    // Create group
    const group = await storage.createNotificationGroup({
      name,
      employee_ids,
      created_by: req.user.id
    });
    
    // Add members
    for (const employeeId of employee_ids) {
      const user = await storage.getUserByEmployeeId(employeeId);
      if (user) {
        await storage.addGroupMember({
          group_id: group.id,
          user_id: user.id,
          employee_id: employeeId
        });
      }
    }
    
    res.status(201).json(group);
  } catch (error) {
    console.error('Create notification group error:', error);
    res.status(500).json({ error: 'Failed to create notification group' });
  }
});

router.get('/notification/messages/:groupId', requireAuth, async (req: any, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const offset = parseInt(req.query.offset) || 0;
    
    // Check if user is member of group
    const userGroups = await storage.getUserGroups(req.user.id);
    if (!userGroups.includes(req.params.groupId)) {
      return res.status(403).json({ error: 'Not a member of this group' });
    }
    
    const messages = await storage.getMessages(req.params.groupId, limit, offset);
    res.json(messages);
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: 'Failed to get messages' });
  }
});

router.post('/notification/messages', requireAuth, validateFields(['group_id', 'content']), async (req: any, res) => {
  try {
    const { group_id, content } = req.body;
    
    // Check if user is member of group
    const userGroups = await storage.getUserGroups(req.user.id);
    if (!userGroups.includes(group_id)) {
      return res.status(403).json({ error: 'Not a member of this group' });
    }
    
    // Get employee name
    const employee = await storage.getEmployeeByEmployeeId(req.user.employee_id);
    
    const message = await storage.createMessage({
      group_id,
      sender_id: req.user.id,
      sender_name: employee?.name || req.user.employee_id,
      content
    });
    
    // Emit to WebSocket clients
    if (req.app.locals.wss) {
      req.app.locals.wss.clients.forEach((client: any) => {
        if (client.readyState === WebSocket.OPEN && client.groups?.includes(group_id)) {
          client.send(JSON.stringify({
            type: 'new_message',
            message
          }));
        }
      });
    }
    
    res.status(201).json(message);
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// WebSocket setup function
export function setupWebSocket(server: http.Server, app: any) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  wss.on('connection', async (ws: any, req: any) => {
    console.log('New WebSocket connection');
    
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        if (data.type === 'join_groups' && data.userId) {
          // Get user's groups
          const groups = await storage.getUserGroups(data.userId);
          ws.groups = groups;
          ws.userId = data.userId;
          
          ws.send(JSON.stringify({
            type: 'groups_joined',
            groups
          }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });
  
  app.locals.wss = wss;
  
  return wss;
}

export default router;