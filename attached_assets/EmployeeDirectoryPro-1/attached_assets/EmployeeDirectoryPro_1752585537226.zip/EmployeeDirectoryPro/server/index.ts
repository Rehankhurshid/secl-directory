import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { createServer } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { setupWebSocket } from './routes.js';
import { setupVite } from './vite.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Basic middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Session management
app.use((req: any, res: any, next: any) => {
  req.session = {
    sessionId: req.cookies.sessionId || null
  };
  next();
});

// Static files for uploads
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Import and use routes
import('./routes.js').then(({ default: routes }) => {
  app.use('/api', routes);
});

// Create HTTP server
const httpServer = createServer(app);

// Setup WebSocket
setupWebSocket(httpServer, app);

// Setup Vite in development
if (process.env.NODE_ENV !== 'production') {
  setupVite(app).then(() => {
    // Start server after Vite is set up
    httpServer.listen(port, '0.0.0.0', () => {
      console.log(`Server running on http://0.0.0.0:${port}`);
    });
  });
} else {
  // Serve production build
  app.use(express.static(path.join(__dirname, '../dist/client')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/client/index.html'));
  });
  
  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${port}`);
  });
}