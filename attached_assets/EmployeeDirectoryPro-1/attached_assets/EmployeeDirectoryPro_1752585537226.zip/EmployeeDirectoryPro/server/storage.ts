import { users, sessions, otpCodes, employees, notificationGroups, notificationGroupMembers, notificationMessages } from "@shared/schema";
import type { User, InsertUser, Session, InsertSession, OtpCode, InsertOtpCode, Employee, InsertEmployee, NotificationGroup, InsertNotificationGroup, NotificationGroupMember, InsertNotificationGroupMember, NotificationMessage, InsertNotificationMessage } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, or, ilike, inArray, gte } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmployeeId(employeeId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  
  // Session operations
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  deleteSession(id: string): Promise<void>;
  deleteExpiredSessions(): Promise<void>;
  
  // OTP operations
  createOtpCode(otpCode: InsertOtpCode): Promise<OtpCode>;
  getValidOtpCode(employeeId: string, code: string): Promise<OtpCode | undefined>;
  markOtpAsUsed(id: string): Promise<void>;
  deleteExpiredOtpCodes(): Promise<void>;
  
  // Employee operations
  getEmployee(id: string): Promise<Employee | undefined>;
  getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined>;
  getEmployees(options: {
    page: number;
    limit: number;
    search?: string;
    department?: string;
    designation?: string;
    location?: string;
    category?: string;
    grade?: string;
    gender?: string;
    blood_group?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<{ employees: Employee[]; total: number }>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, updates: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: string): Promise<void>;
  getFilterOptions(): Promise<{
    departments: string[];
    designations: string[];
    locations: string[];
    categories: string[];
    grades: string[];
    genders: string[];
    bloodGroups: string[];
  }>;
  
  // Notification Group operations
  getNotificationGroup(id: string): Promise<NotificationGroup | undefined>;
  getNotificationGroups(userId: string): Promise<NotificationGroup[]>;
  createNotificationGroup(group: InsertNotificationGroup): Promise<NotificationGroup>;
  updateNotificationGroup(id: string, updates: Partial<InsertNotificationGroup>): Promise<NotificationGroup | undefined>;
  deleteNotificationGroup(id: string): Promise<void>;
  
  // Notification Group Member operations
  getGroupMembers(groupId: string): Promise<NotificationGroupMember[]>;
  addGroupMember(member: InsertNotificationGroupMember): Promise<NotificationGroupMember>;
  removeGroupMember(groupId: string, userId: string): Promise<void>;
  getUserGroups(userId: string): Promise<string[]>;
  
  // Notification Message operations
  getMessages(groupId: string, limit?: number, offset?: number): Promise<NotificationMessage[]>;
  createMessage(message: InsertNotificationMessage): Promise<NotificationMessage>;
  getMessageCount(groupId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmployeeId(employeeId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.employee_id, employeeId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user || undefined;
  }
  
  // Session operations
  async getSession(id: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session || undefined;
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(insertSession).returning();
    return session;
  }

  async deleteSession(id: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.id, id));
  }

  async deleteExpiredSessions(): Promise<void> {
    await db.delete(sessions).where(gte(sessions.expires_at, new Date()));
  }
  
  // OTP operations
  async createOtpCode(insertOtp: InsertOtpCode): Promise<OtpCode> {
    const [otp] = await db.insert(otpCodes).values(insertOtp).returning();
    return otp;
  }

  async getValidOtpCode(employeeId: string, code: string): Promise<OtpCode | undefined> {
    const [otp] = await db.select().from(otpCodes)
      .where(and(
        eq(otpCodes.employee_id, employeeId),
        eq(otpCodes.otp_code, code),
        eq(otpCodes.is_used, false),
        gte(otpCodes.expires_at, new Date())
      ));
    return otp || undefined;
  }

  async markOtpAsUsed(id: string): Promise<void> {
    await db.update(otpCodes).set({ is_used: true }).where(eq(otpCodes.id, id));
  }

  async deleteExpiredOtpCodes(): Promise<void> {
    await db.delete(otpCodes).where(gte(otpCodes.expires_at, new Date()));
  }
  
  // Employee operations
  async getEmployee(id: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee || undefined;
  }

  async getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.employee_id, employeeId));
    return employee || undefined;
  }

  async getEmployees(options: {
    page: number;
    limit: number;
    search?: string;
    department?: string;
    designation?: string;
    location?: string;
    category?: string;
    grade?: string;
    gender?: string;
    blood_group?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
  }): Promise<{ employees: Employee[]; total: number }> {
    const offset = (options.page - 1) * options.limit;
    let query = db.select().from(employees);
    let countQuery = db.select().from(employees);
    
    // Build where conditions
    const conditions = [];
    
    if (options.search) {
      conditions.push(or(
        ilike(employees.name, `%${options.search}%`),
        ilike(employees.employee_id, `%${options.search}%`),
        ilike(employees.email, `%${options.search}%`)
      ));
    }
    
    if (options.department) conditions.push(eq(employees.department, options.department));
    if (options.designation) conditions.push(eq(employees.designation, options.designation));
    if (options.location) conditions.push(eq(employees.location, options.location));
    if (options.category) conditions.push(eq(employees.category, options.category));
    if (options.grade) conditions.push(eq(employees.grade, options.grade));
    if (options.gender) conditions.push(eq(employees.gender, options.gender));
    if (options.blood_group) conditions.push(eq(employees.blood_group, options.blood_group));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
      countQuery = countQuery.where(and(...conditions));
    }
    
    // Sorting
    if (options.sortBy) {
      const sortField = employees[options.sortBy as keyof typeof employees];
      if (sortField) {
        query = options.sortOrder === 'desc' 
          ? query.orderBy(desc(sortField))
          : query.orderBy(sortField);
      }
    }
    
    // Pagination
    query = query.limit(options.limit).offset(offset);
    
    const [results, totalResults] = await Promise.all([
      query,
      countQuery
    ]);
    
    return {
      employees: results,
      total: totalResults.length
    };
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const [employee] = await db.insert(employees).values(insertEmployee).returning();
    return employee;
  }

  async updateEmployee(id: string, updates: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const [employee] = await db.update(employees).set(updates).where(eq(employees.id, id)).returning();
    return employee || undefined;
  }

  async deleteEmployee(id: string): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  async getFilterOptions(): Promise<{
    departments: string[];
    designations: string[];
    locations: string[];
    categories: string[];
    grades: string[];
    genders: string[];
    bloodGroups: string[];
  }> {
    const [depts, desigs, locs, cats, grades, genders, bloodGroups] = await Promise.all([
      db.selectDistinct({ value: employees.department }).from(employees).where(employees.department),
      db.selectDistinct({ value: employees.designation }).from(employees).where(employees.designation),
      db.selectDistinct({ value: employees.location }).from(employees).where(employees.location),
      db.selectDistinct({ value: employees.category }).from(employees).where(employees.category),
      db.selectDistinct({ value: employees.grade }).from(employees).where(employees.grade),
      db.selectDistinct({ value: employees.gender }).from(employees).where(employees.gender),
      db.selectDistinct({ value: employees.blood_group }).from(employees).where(employees.blood_group)
    ]);
    
    return {
      departments: depts.map(d => d.value!).filter(Boolean),
      designations: desigs.map(d => d.value!).filter(Boolean),
      locations: locs.map(d => d.value!).filter(Boolean),
      categories: cats.map(d => d.value!).filter(Boolean),
      grades: grades.map(d => d.value!).filter(Boolean),
      genders: genders.map(d => d.value!).filter(Boolean),
      bloodGroups: bloodGroups.map(d => d.value!).filter(Boolean)
    };
  }
  
  // Notification Group operations
  async getNotificationGroup(id: string): Promise<NotificationGroup | undefined> {
    const [group] = await db.select().from(notificationGroups).where(eq(notificationGroups.id, id));
    return group || undefined;
  }

  async getNotificationGroups(userId: string): Promise<NotificationGroup[]> {
    const userGroupIds = await this.getUserGroups(userId);
    if (userGroupIds.length === 0) return [];
    
    return db.select().from(notificationGroups)
      .where(inArray(notificationGroups.id, userGroupIds));
  }

  async createNotificationGroup(insertGroup: InsertNotificationGroup): Promise<NotificationGroup> {
    const [group] = await db.insert(notificationGroups).values(insertGroup).returning();
    return group;
  }

  async updateNotificationGroup(id: string, updates: Partial<InsertNotificationGroup>): Promise<NotificationGroup | undefined> {
    const [group] = await db.update(notificationGroups).set(updates).where(eq(notificationGroups.id, id)).returning();
    return group || undefined;
  }

  async deleteNotificationGroup(id: string): Promise<void> {
    await db.delete(notificationGroups).where(eq(notificationGroups.id, id));
  }
  
  // Notification Group Member operations
  async getGroupMembers(groupId: string): Promise<NotificationGroupMember[]> {
    return db.select().from(notificationGroupMembers).where(eq(notificationGroupMembers.group_id, groupId));
  }

  async addGroupMember(insertMember: InsertNotificationGroupMember): Promise<NotificationGroupMember> {
    const [member] = await db.insert(notificationGroupMembers).values(insertMember).returning();
    return member;
  }

  async removeGroupMember(groupId: string, userId: string): Promise<void> {
    await db.delete(notificationGroupMembers)
      .where(and(
        eq(notificationGroupMembers.group_id, groupId),
        eq(notificationGroupMembers.user_id, userId)
      ));
  }

  async getUserGroups(userId: string): Promise<string[]> {
    const memberships = await db.select({ groupId: notificationGroupMembers.group_id })
      .from(notificationGroupMembers)
      .where(eq(notificationGroupMembers.user_id, userId));
    return memberships.map(m => m.groupId);
  }
  
  // Notification Message operations
  async getMessages(groupId: string, limit: number = 50, offset: number = 0): Promise<NotificationMessage[]> {
    return db.select().from(notificationMessages)
      .where(eq(notificationMessages.group_id, groupId))
      .orderBy(desc(notificationMessages.created_at))
      .limit(limit)
      .offset(offset);
  }

  async createMessage(insertMessage: InsertNotificationMessage): Promise<NotificationMessage> {
    const [message] = await db.insert(notificationMessages).values(insertMessage).returning();
    return message;
  }

  async getMessageCount(groupId: string): Promise<number> {
    const [result] = await db.select({ count: notificationMessages.id })
      .from(notificationMessages)
      .where(eq(notificationMessages.group_id, groupId));
    return result?.count ? 1 : 0;
  }
}

export const storage = new DatabaseStorage();