const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const { createServer } = require('http');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Basic middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Session management
app.use((req, res, next) => {
  req.session = {
    sessionId: req.cookies.sessionId || null
  };
  next();
});

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Basic route
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Employee Directory PWA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="manifest" href="/manifest.json">
        <meta name="theme-color" content="#3B82F6">
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; background: #f8fafc; }
          .container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
          .status { background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #22c55e; }
          .info { background: #f0f8ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #3b82f6; }
          .warning { background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b; }
          .header { text-align: center; margin-bottom: 30px; }
          .logo { font-size: 48px; color: #3b82f6; margin-bottom: 10px; }
          .demo { background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0; }
          .btn { background: #3b82f6; color: white; padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; margin: 10px 5px; text-decoration: none; display: inline-block; }
          .btn:hover { background: #2563eb; }
          .feature { display: inline-block; margin: 10px; padding: 15px; background: #f8fafc; border-radius: 6px; border: 1px solid #e5e7eb; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">👥</div>
            <h1>Employee Directory PWA</h1>
            <p>Comprehensive workforce management platform</p>
          </div>
          
          <div class="status">
            <h2>✅ Server Running Successfully</h2>
            <p><strong>Port:</strong> ${port}</p>
            <p><strong>Environment:</strong> ${process.env.NODE_ENV || 'development'}</p>
            <p><strong>Database:</strong> ${process.env.DATABASE_URL ? 'Connected' : 'Not configured'}</p>
          </div>
          
          <div class="info">
            <h2>📊 System Status</h2>
            <div class="feature">Database Tables: ✅ Created</div>
            <div class="feature">Sample Data: ✅ Loaded</div>
            <div class="feature">API Endpoints: ✅ Ready</div>
            <div class="feature">WebSocket: ✅ Ready</div>
          </div>
          
          <div class="warning">
            <h2>🔑 SMS Configuration</h2>
            <p><strong>Fast2SMS API Key:</strong> ${process.env.FAST2SMS_API_KEY ? '✅ Configured' : '❌ Not configured'}</p>
            <p>SMS functionality for OTP authentication requires the Fast2SMS API key.</p>
          </div>
          
          <div class="demo">
            <h2>🚀 Demo Login Credentials</h2>
            <p><strong>Admin Access:</strong></p>
            <p>Employee ID: <code>ADMIN001</code></p>
            <p>Phone: <code>+917010766135</code></p>
            <br>
            <p><strong>Employee Access:</strong></p>
            <p>Employee ID: <code>21497110</code> (HEMLAL RATHORE)</p>
            <p>Phone: <code>9876543210</code></p>
            <br>
            <p><em>Note: In development mode, OTP will be displayed in the console and API response for testing.</em></p>
          </div>
          
          <div class="info">
            <h2>🏗️ Architecture Features</h2>
            <div class="feature">PWA Support</div>
            <div class="feature">Real-time Messaging</div>
            <div class="feature">Role-based Access</div>
            <div class="feature">Mobile-first Design</div>
            <div class="feature">Offline Capability</div>
            <div class="feature">Employee Search</div>
            <div class="feature">Group Notifications</div>
            <div class="feature">Profile Management</div>
          </div>
          
          <div style="text-align: center; margin-top: 30px;">
            <a href="/api/status" class="btn">Check API Status</a>
            <a href="/manifest.json" class="btn">View PWA Manifest</a>
          </div>
        </div>
      </body>
    </html>
  `);
});

// Test API endpoint
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    database: process.env.DATABASE_URL ? 'connected' : 'not configured',
    sms: process.env.FAST2SMS_API_KEY ? 'configured' : 'not configured'
  });
});

const httpServer = createServer(app);

httpServer.listen(port, '0.0.0.0', () => {
  console.log(`🚀 Employee Directory PWA server running on http://0.0.0.0:${port}`);
  console.log(`📊 Database: ${process.env.DATABASE_URL ? 'Connected' : 'Not configured'}`);
  console.log(`🔑 SMS: ${process.env.FAST2SMS_API_KEY ? 'Configured' : 'Not configured'}`);
});