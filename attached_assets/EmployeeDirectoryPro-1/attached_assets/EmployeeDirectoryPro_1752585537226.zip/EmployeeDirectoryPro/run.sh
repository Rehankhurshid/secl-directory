#!/bin/bash

# Employee Directory PWA Startup Script
echo "🚀 Starting Employee Directory PWA..."
echo "📊 Database: ${DATABASE_URL:+Connected}"
echo "🔑 SMS: ${FAST2SMS_API_KEY:+Configured}"
echo ""

# Start the Node.js server
exec node start.js