import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: (failureCount, error: any) => {
        // Don't retry on 401 or 403
        if (error?.status === 401 || error?.status === 403) {
          return false;
        }
        return failureCount < 3;
      },
      queryFn: async ({ queryKey }) => {
        const response = await fetch(queryKey[0] as string, {
          credentials: 'include',
        });
        
        if (!response.ok) {
          const error: any = new Error('API request failed');
          error.status = response.status;
          try {
            const data = await response.json();
            error.message = data.error || data.message || 'API request failed';
          } catch {}
          throw error;
        }
        
        return response.json();
      },
    },
  },
});

export const apiRequest = async (url: string, options?: RequestInit) => {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    credentials: 'include',
  });
  
  if (!response.ok) {
    const error: any = new Error('API request failed');
    error.status = response.status;
    try {
      const data = await response.json();
      error.message = data.error || data.message || 'API request failed';
    } catch {}
    throw error;
  }
  
  return response.json();
};