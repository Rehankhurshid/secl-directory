import { QueryClientProvider } from '@tanstack/react-query';
import { Router, Route, Switch, Redirect } from 'wouter';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { queryClient } from '@/lib/queryClient';
import { useQuery } from '@tanstack/react-query';

// Pages
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import EmployeesPage from '@/pages/EmployeesPage';
import ProfilePage from '@/pages/ProfilePage';
import NotificationsPage from '@/pages/NotificationsPage';
import AdminPage from '@/pages/AdminPage';

// Layout components
import Layout from '@/components/Layout';
import ProtectedRoute from '@/components/ProtectedRoute';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <Router>
          <Switch>
            <Route path="/login" component={LoginPage} />
            
            <Route path="/">
              <ProtectedRoute>
                <Layout>
                  <DashboardPage />
                </Layout>
              </ProtectedRoute>
            </Route>
            
            <Route path="/employees">
              <ProtectedRoute>
                <Layout>
                  <EmployeesPage />
                </Layout>
              </ProtectedRoute>
            </Route>
            
            <Route path="/profile/:id?">
              {(params) => (
                <ProtectedRoute>
                  <Layout>
                    <ProfilePage employeeId={params.id} />
                  </Layout>
                </ProtectedRoute>
              )}
            </Route>
            
            <Route path="/notifications">
              <ProtectedRoute>
                <Layout>
                  <NotificationsPage />
                </Layout>
              </ProtectedRoute>
            </Route>
            
            <Route path="/admin">
              <ProtectedRoute requireAdmin>
                <Layout>
                  <AdminPage />
                </Layout>
              </ProtectedRoute>
            </Route>
            
            <Route>
              <Redirect to="/" />
            </Route>
          </Switch>
        </Router>
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;