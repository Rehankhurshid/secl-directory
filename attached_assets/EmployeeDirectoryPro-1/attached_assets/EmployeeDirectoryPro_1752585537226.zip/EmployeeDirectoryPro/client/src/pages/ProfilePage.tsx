import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft,
  Phone,
  Mail,
  MapPin,
  Building,
  Calendar,
  User,
  CreditCard,
  Briefcase,
  Heart,
  Shield,
  FileText
} from 'lucide-react';

interface ProfilePageProps {
  employeeId?: string;
}

export default function ProfilePage({ employeeId }: ProfilePageProps) {
  const [, setLocation] = useLocation();
  
  const { data: currentUser } = useQuery({
    queryKey: ['/api/auth/me'],
  });

  // If no employeeId is provided, show current user's profile
  const profileId = employeeId || currentUser?.employee?.id;
  
  const { data: employee, isLoading } = useQuery({
    queryKey: [`/api/employees/${profileId}`],
    enabled: !!profileId,
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Skeleton className="h-4 w-4" />
          <Skeleton className="h-8 w-32" />
        </div>
        <div className="flex items-center space-x-4">
          <Skeleton className="h-24 w-24 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Employee not found</p>
        <Button onClick={() => setLocation('/employees')} className="mt-4">
          Back to Directory
        </Button>
      </div>
    );
  }

  const personalInfo = [
    { label: 'Employee ID', value: employee.employee_id, icon: User },
    { label: 'Date of Birth', value: employee.dob, icon: Calendar },
    { label: 'Gender', value: employee.gender, icon: User },
    { label: 'Blood Group', value: employee.blood_group, icon: Heart },
    { label: 'Father\'s Name', value: employee.father_name, icon: User },
    { label: 'Marital Status', value: employee.marital_status, icon: Heart },
    { label: 'Spouse Name', value: employee.spouse_name, icon: User },
    { label: 'Category', value: employee.category, icon: Shield },
    { label: 'Religion', value: employee.religion_code, icon: Shield },
  ];

  const contactInfo = [
    { label: 'Phone 1', value: employee.phno_1, icon: Phone, link: `tel:${employee.phno_1}` },
    { label: 'Phone 2', value: employee.phno_2, icon: Phone, link: `tel:${employee.phno_2}` },
    { label: 'Email', value: employee.email || employee.email_id, icon: Mail, link: `mailto:${employee.email || employee.email_id}` },
    { label: 'Present Address', value: employee.present_address, icon: MapPin },
    { label: 'Permanent Address', value: employee.permanent_address, icon: MapPin },
  ];

  const professionalInfo = [
    { label: 'Department', value: employee.department, icon: Building },
    { label: 'Designation', value: employee.designation, icon: Briefcase },
    { label: 'Location', value: employee.location, icon: MapPin },
    { label: 'Area', value: employee.area_name, icon: MapPin },
    { label: 'Unit', value: employee.unit_name, icon: Building },
    { label: 'Grade', value: employee.grade, icon: Shield },
    { label: 'Discipline', value: employee.discipline, icon: Briefcase },
    { label: 'Date of Appointment', value: employee.dt_appt, icon: Calendar },
    { label: 'Area Joining Date', value: employee.area_joining_date, icon: Calendar },
    { label: 'Expected Exit Date', value: employee.expected_exit_date, icon: Calendar },
  ];

  const financialInfo = [
    { label: 'Bank Account', value: employee.bank_acc_no, icon: CreditCard },
    { label: 'Bank', value: employee.bank, icon: Building },
    { label: 'CMPF', value: employee.cmpf, icon: FileText },
    { label: 'PAN Number', value: employee.pan_no, icon: FileText },
    { label: 'Aadhaar', value: employee.aadhaar, icon: FileText },
    { label: 'Basic Pay', value: employee.basic_pay, icon: CreditCard },
  ];

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation('/employees')}
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Directory
      </Button>

      {/* Profile Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={employee.profile_image} />
              <AvatarFallback className="text-2xl">
                {employee.name?.split(' ').map((n: string) => n[0]).join('') || 'E'}
              </AvatarFallback>
            </Avatar>
            <div className="text-center md:text-left space-y-2">
              <h1 className="text-2xl font-bold">{employee.name}</h1>
              <p className="text-muted-foreground">
                {employee.designation} • {employee.department}
              </p>
              <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                {employee.phno_1 && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={`tel:${employee.phno_1}`}>
                      <Phone className="mr-2 h-4 w-4" />
                      Call
                    </a>
                  </Button>
                )}
                {(employee.email || employee.email_id) && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={`mailto:${employee.email || employee.email_id}`}>
                      <Mail className="mr-2 h-4 w-4" />
                      Email
                    </a>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Information */}
      <Tabs defaultValue="personal" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="personal">Personal</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="professional">Professional</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
        </TabsList>

        <TabsContent value="personal">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Personal details and family information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {personalInfo.map((item) => {
                  const Icon = item.icon;
                  return item.value ? (
                    <div key={item.label} className="flex items-start space-x-3">
                      <Icon className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-sm text-muted-foreground">{item.value}</p>
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>Phone numbers, email, and addresses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {contactInfo.map((item) => {
                  const Icon = item.icon;
                  return item.value ? (
                    <div key={item.label} className="flex items-start space-x-3">
                      <Icon className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        {item.link ? (
                          <a href={item.link} className="text-sm text-primary hover:underline">
                            {item.value}
                          </a>
                        ) : (
                          <p className="text-sm text-muted-foreground">{item.value}</p>
                        )}
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="professional">
          <Card>
            <CardHeader>
              <CardTitle>Professional Information</CardTitle>
              <CardDescription>Work details and employment history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {professionalInfo.map((item) => {
                  const Icon = item.icon;
                  return item.value ? (
                    <div key={item.label} className="flex items-start space-x-3">
                      <Icon className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-sm text-muted-foreground">{item.value}</p>
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial">
          <Card>
            <CardHeader>
              <CardTitle>Financial Information</CardTitle>
              <CardDescription>Banking and financial details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {financialInfo.map((item) => {
                  const Icon = item.icon;
                  return item.value ? (
                    <div key={item.label} className="flex items-start space-x-3">
                      <Icon className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-sm text-muted-foreground">{item.value}</p>
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}