import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { 
  Plus, 
  Send, 
  Users as UsersIcon,
  MessageSquare,
  Bell,
  Loader2,
  CheckCircle2,
  X
} from 'lucide-react';

const createGroupSchema = z.object({
  name: z.string().min(1, 'Group name is required').max(50),
  employee_ids: z.array(z.string()).min(1, 'Select at least one employee'),
});

const sendMessageSchema = z.object({
  content: z.string().min(1, 'Message cannot be empty').max(1000),
});

export default function NotificationsPage() {
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  const [createGroupOpen, setCreateGroupOpen] = useState(false);
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: userData } = useQuery({
    queryKey: ['/api/auth/me'],
  });

  const { data: groups, isLoading: groupsLoading } = useQuery({
    queryKey: ['/api/notification/groups'],
  });

  const { data: employees } = useQuery({
    queryKey: ['/api/employees?limit=1000'],
  });

  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: selectedGroup ? [`/api/notification/messages/${selectedGroup.id}`] : [],
    enabled: !!selectedGroup,
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  const createGroupForm = useForm<z.infer<typeof createGroupSchema>>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: '',
      employee_ids: [],
    },
  });

  const messageForm = useForm<z.infer<typeof sendMessageSchema>>({
    resolver: zodResolver(sendMessageSchema),
    defaultValues: {
      content: '',
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: (data: z.infer<typeof createGroupSchema>) =>
      apiRequest('/api/notification/groups', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: (newGroup) => {
      queryClient.invalidateQueries({ queryKey: ['/api/notification/groups'] });
      setCreateGroupOpen(false);
      createGroupForm.reset();
      setSelectedEmployees([]);
      setSelectedGroup(newGroup);
      toast({
        title: 'Group Created',
        description: 'Notification group created successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data: z.infer<typeof sendMessageSchema>) =>
      apiRequest('/api/notification/messages', {
        method: 'POST',
        body: JSON.stringify({
          group_id: selectedGroup.id,
          content: data.content,
        }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/notification/messages/${selectedGroup.id}`] 
      });
      messageForm.reset();
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const onCreateGroup = (data: z.infer<typeof createGroupSchema>) => {
    createGroupMutation.mutate({
      ...data,
      employee_ids: selectedEmployees,
    });
  };

  const onSendMessage = (data: z.infer<typeof sendMessageSchema>) => {
    sendMessageMutation.mutate(data);
  };

  const toggleEmployeeSelection = (employeeId: string) => {
    setSelectedEmployees(prev =>
      prev.includes(employeeId)
        ? prev.filter(id => id !== employeeId)
        : [...prev, employeeId]
    );
  };

  // Setup WebSocket connection
  useEffect(() => {
    if (!userData?.user?.id) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      socket.send(JSON.stringify({
        type: 'join_groups',
        userId: userData.user.id,
      }));
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'new_message' && selectedGroup?.id === data.message.group_id) {
        queryClient.invalidateQueries({ 
          queryKey: [`/api/notification/messages/${selectedGroup.id}`] 
        });
      }
    };

    return () => {
      socket.close();
    };
  }, [userData, selectedGroup]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (groupsLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-4 md:grid-cols-3">
          <Skeleton className="h-96" />
          <Skeleton className="h-96 md:col-span-2" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Notifications</h1>
          <p className="text-muted-foreground">
            Real-time group messaging and notifications
          </p>
        </div>
        <Dialog open={createGroupOpen} onOpenChange={setCreateGroupOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Group
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
            <DialogHeader>
              <DialogTitle>Create Notification Group</DialogTitle>
              <DialogDescription>
                Create a new group to send notifications to selected employees
              </DialogDescription>
            </DialogHeader>
            <Form {...createGroupForm}>
              <form onSubmit={createGroupForm.handleSubmit(onCreateGroup)} className="space-y-4">
                <FormField
                  control={createGroupForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Group Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter group name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="space-y-2">
                  <FormLabel>Select Employees</FormLabel>
                  <FormDescription>
                    Choose employees to add to this group ({selectedEmployees.length} selected)
                  </FormDescription>
                  <ScrollArea className="h-64 rounded-md border p-4">
                    <div className="space-y-2">
                      {employees?.employees?.map((employee: any) => (
                        <div
                          key={employee.employee_id}
                          className={`flex items-center space-x-3 p-2 rounded-md cursor-pointer hover:bg-accent ${
                            selectedEmployees.includes(employee.employee_id) ? 'bg-accent' : ''
                          }`}
                          onClick={() => toggleEmployeeSelection(employee.employee_id)}
                        >
                          <div className="flex-1">
                            <p className="text-sm font-medium">{employee.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {employee.employee_id} • {employee.designation}
                            </p>
                          </div>
                          {selectedEmployees.includes(employee.employee_id) && (
                            <CheckCircle2 className="h-4 w-4 text-primary" />
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setCreateGroupOpen(false);
                      createGroupForm.reset();
                      setSelectedEmployees([]);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createGroupMutation.isPending || selectedEmployees.length === 0}
                  >
                    {createGroupMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Create Group
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {/* Groups List */}
        <Card>
          <CardHeader>
            <CardTitle>Notification Groups</CardTitle>
            <CardDescription>Select a group to view messages</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px]">
              <div className="space-y-2">
                {groups?.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">
                    No groups yet. Create one to get started!
                  </p>
                ) : (
                  groups?.map((group: any) => (
                    <button
                      key={group.id}
                      className={`w-full text-left p-3 rounded-md transition-colors ${
                        selectedGroup?.id === group.id
                          ? 'bg-primary text-primary-foreground'
                          : 'hover:bg-accent'
                      }`}
                      onClick={() => setSelectedGroup(group)}
                    >
                      <div className="flex items-center space-x-3">
                        <UsersIcon className="h-5 w-5" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{group.name}</p>
                          <p className={`text-xs truncate ${
                            selectedGroup?.id === group.id 
                              ? 'text-primary-foreground/70' 
                              : 'text-muted-foreground'
                          }`}>
                            {group.employee_ids.length} members
                          </p>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Messages */}
        <Card className="md:col-span-2">
          {selectedGroup ? (
            <>
              <CardHeader>
                <CardTitle>{selectedGroup.name}</CardTitle>
                <CardDescription>
                  {selectedGroup.employee_ids.length} members in this group
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Messages Area */}
                  <ScrollArea className="h-[400px] rounded-md border p-4">
                    {messagesLoading ? (
                      <div className="space-y-2">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="flex items-start space-x-3">
                            <Skeleton className="h-8 w-8 rounded-full" />
                            <div className="space-y-1">
                              <Skeleton className="h-4 w-32" />
                              <Skeleton className="h-12 w-64" />
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : messages?.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No messages yet. Start the conversation!
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {messages?.map((message: any) => (
                          <div 
                            key={message.id} 
                            className={`flex items-start space-x-3 ${
                              message.sender_id === userData?.user?.id ? 'justify-end' : ''
                            }`}
                          >
                            {message.sender_id !== userData?.user?.id && (
                              <Avatar className="h-8 w-8">
                                <AvatarFallback>
                                  {message.sender_name.split(' ').map((n: string) => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                            )}
                            <div className={`space-y-1 ${
                              message.sender_id === userData?.user?.id ? 'text-right' : ''
                            }`}>
                              <p className="text-xs text-muted-foreground">
                                {message.sender_name} • {new Date(message.created_at).toLocaleString()}
                              </p>
                              <div className={`rounded-lg p-3 max-w-md ${
                                message.sender_id === userData?.user?.id
                                  ? 'bg-primary text-primary-foreground ml-auto'
                                  : 'bg-muted'
                              }`}>
                                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </div>
                    )}
                  </ScrollArea>

                  {/* Message Input */}
                  <Form {...messageForm}>
                    <form onSubmit={messageForm.handleSubmit(onSendMessage)} className="flex space-x-2">
                      <FormField
                        control={messageForm.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormControl>
                              <Textarea 
                                placeholder="Type a message..." 
                                className="min-h-[60px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit"
                        disabled={sendMessageMutation.isPending}
                      >
                        {sendMessageMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </form>
                  </Form>
                </div>
              </CardContent>
            </>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center space-y-2">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground" />
                <p className="text-muted-foreground">
                  Select a group to view messages
                </p>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}