import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'wouter';
import { 
  Users, 
  Building, 
  MapPin, 
  TrendingUp,
  UserCheck,
  Bell,
  ChevronRight,
  Download,
  Plus
} from 'lucide-react';

export default function DashboardPage() {
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/me'],
  });

  const { data: employeesData, isLoading: employeesLoading } = useQuery({
    queryKey: ['/api/employees?limit=5'],
  });

  const { data: filterOptions, isLoading: filterLoading } = useQuery({
    queryKey: ['/api/employees/filter-options'],
  });

  const { data: notificationGroups, isLoading: groupsLoading } = useQuery({
    queryKey: ['/api/notification/groups'],
  });

  const isAdmin = userData?.user?.is_admin;

  if (userLoading || employeesLoading || filterLoading || groupsLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  const stats = [
    {
      title: 'Total Employees',
      value: employeesData?.pagination?.total || 0,
      icon: Users,
      color: 'text-blue-500',
    },
    {
      title: 'Departments',
      value: filterOptions?.departments?.length || 0,
      icon: Building,
      color: 'text-green-500',
    },
    {
      title: 'Locations',
      value: filterOptions?.locations?.length || 0,
      icon: MapPin,
      color: 'text-purple-500',
    },
    {
      title: 'Notification Groups',
      value: notificationGroups?.length || 0,
      icon: Bell,
      color: 'text-orange-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          Welcome back, {userData?.employee?.name || userData?.user?.employee_id}!
        </h1>
        <p className="text-muted-foreground">
          Here's an overview of your employee directory
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Link href="/employees">
              <Button variant="outline" className="w-full justify-start">
                <Users className="mr-2 h-4 w-4" />
                Browse Employees
              </Button>
            </Link>
            <Link href="/notifications">
              <Button variant="outline" className="w-full justify-start">
                <Bell className="mr-2 h-4 w-4" />
                View Notifications
              </Button>
            </Link>
            <Link href="/profile">
              <Button variant="outline" className="w-full justify-start">
                <UserCheck className="mr-2 h-4 w-4" />
                My Profile
              </Button>
            </Link>
            {isAdmin && (
              <Link href="/admin">
                <Button variant="outline" className="w-full justify-start">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Employee
                </Button>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Employees */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Employees</CardTitle>
            <CardDescription>Latest additions to the directory</CardDescription>
          </div>
          <Link href="/employees">
            <Button variant="ghost" size="sm">
              View All
              <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {employeesData?.employees?.map((employee: any) => (
              <div key={employee.id} className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={employee.profile_image} />
                  <AvatarFallback>
                    {employee.name?.split(' ').map((n: string) => n[0]).join('') || 'E'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <Link href={`/profile/${employee.id}`}>
                    <p className="text-sm font-medium hover:underline">
                      {employee.name}
                    </p>
                  </Link>
                  <p className="text-sm text-muted-foreground">
                    {employee.designation} • {employee.department}
                  </p>
                </div>
                <div className="text-sm text-muted-foreground">
                  {employee.location}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* PWA Install Prompt */}
      <Card>
        <CardHeader>
          <CardTitle>Install Employee Directory App</CardTitle>
          <CardDescription>
            Get the full app experience with offline access and push notifications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button className="w-full md:w-auto">
            <Download className="mr-2 h-4 w-4" />
            Install App
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}