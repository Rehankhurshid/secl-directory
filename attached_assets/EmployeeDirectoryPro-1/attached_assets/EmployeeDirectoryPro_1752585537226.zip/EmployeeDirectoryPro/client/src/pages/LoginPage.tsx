import { useState } from 'react';
import { useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Shield, Users, MessageSquare, Download } from 'lucide-react';

const loginSchema = z.object({
  employee_id: z.string().min(1, 'Employee ID is required'),
});

const otpSchema = z.object({
  otp_code: z.string().length(6, 'OTP must be 6 digits'),
});

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<'login' | 'otp'>('login');
  const [employeeId, setEmployeeId] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const { toast } = useToast();

  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      employee_id: '',
    },
  });

  const otpForm = useForm<z.infer<typeof otpSchema>>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      otp_code: '',
    },
  });

  const generateOtpMutation = useMutation({
    mutationFn: (data: z.infer<typeof loginSchema>) => 
      apiRequest('/api/auth/generate-otp', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: (data) => {
      setEmployeeId(loginForm.getValues('employee_id'));
      setPhoneNumber(data.phone_number);
      setStep('otp');
      toast({
        title: 'OTP Sent',
        description: `A 6-digit code has been sent to ${data.phone_number}`,
      });
      // In development, show OTP
      if (data.otp) {
        toast({
          title: 'Development Mode',
          description: `Your OTP is: ${data.otp}`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const verifyOtpMutation = useMutation({
    mutationFn: (data: z.infer<typeof otpSchema>) => 
      apiRequest('/api/auth/verify-otp', {
        method: 'POST',
        body: JSON.stringify({
          employee_id: employeeId,
          otp_code: data.otp_code,
        }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      setLocation('/');
    },
    onError: (error: Error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    },
  });

  const onLoginSubmit = (data: z.infer<typeof loginSchema>) => {
    generateOtpMutation.mutate(data);
  };

  const onOtpSubmit = (data: z.infer<typeof otpSchema>) => {
    verifyOtpMutation.mutate(data);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md space-y-8">
        {/* App Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold tracking-tight">Employee Directory</h1>
          <p className="mt-2 text-muted-foreground">Progressive Web App</p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="space-y-2">
            <Shield className="h-8 w-8 mx-auto text-primary" />
            <p className="text-sm">Secure OTP Login</p>
          </div>
          <div className="space-y-2">
            <Users className="h-8 w-8 mx-auto text-primary" />
            <p className="text-sm">Employee Directory</p>
          </div>
          <div className="space-y-2">
            <MessageSquare className="h-8 w-8 mx-auto text-primary" />
            <p className="text-sm">Real-time Messaging</p>
          </div>
          <div className="space-y-2">
            <Download className="h-8 w-8 mx-auto text-primary" />
            <p className="text-sm">Works Offline</p>
          </div>
        </div>

        {/* Login Card */}
        <Card>
          <CardHeader>
            <CardTitle>{step === 'login' ? 'Sign In' : 'Verify OTP'}</CardTitle>
            <CardDescription>
              {step === 'login' 
                ? 'Enter your employee ID to receive a one-time password'
                : `Enter the 6-digit code sent to ${phoneNumber}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 'login' ? (
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="employee_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Employee ID</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your employee ID" {...field} />
                        </FormControl>
                        <FormDescription>
                          Use ADMIN001 for admin access
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={generateOtpMutation.isPending}
                  >
                    {generateOtpMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Send OTP
                  </Button>
                </form>
              </Form>
            ) : (
              <Form {...otpForm}>
                <form onSubmit={otpForm.handleSubmit(onOtpSubmit)} className="space-y-4">
                  <FormField
                    control={otpForm.control}
                    name="otp_code"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>OTP Code</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter 6-digit OTP" 
                            maxLength={6}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-2">
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={verifyOtpMutation.isPending}
                    >
                      {verifyOtpMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      Verify OTP
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setStep('login');
                        otpForm.reset();
                      }}
                    >
                      Back to Login
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </CardContent>
          <CardFooter className="text-center text-sm text-muted-foreground">
            <p className="w-full">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}