import { useQuery } from '@tanstack/react-query';
import { Redirect } from 'wouter';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

export default function ProtectedRoute({ children, requireAdmin }: ProtectedRouteProps) {
  const { data: userData, isLoading, error } = useQuery({
    queryKey: ['/api/auth/me'],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (error || !userData) {
    return <Redirect to="/login" />;
  }

  if (requireAdmin && !userData.user.is_admin) {
    return <Redirect to="/" />;
  }

  return <>{children}</>;
}